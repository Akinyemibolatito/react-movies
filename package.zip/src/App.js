import './App.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Search from './pages/Search';
import MovieDetail from './pages/MovieDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import AdvancedSearch from './pages/AdvancedSearch';
import Watchlists from './pages/Watchlists';
import WatchlistDetail from './pages/WatchlistDetail';
import Favourites from './pages/Favourites';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/search" element={<Search />} />
        <Route path="/movies/:id" element={<MovieDetail />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/profile" element={
          <ProtectedRoute><Profile /></ProtectedRoute>
        } />
        <Route path="/favorites" element={
          <ProtectedRoute><Favourites /></ProtectedRoute>
        } />
        <Route path="/advanced-search" element={
          <ProtectedRoute><AdvancedSearch /></ProtectedRoute>
        } />
        <Route path="/watchlists" element={
          <ProtectedRoute><Watchlists /></ProtectedRoute>
        } />
        <Route path="/watchlists/:id" element={
          <ProtectedRoute><WatchlistDetail /></ProtectedRoute>
        } />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
